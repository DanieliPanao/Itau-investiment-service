﻿using System;
using System.ComponentModel;
using System.Numerics;
using System.Collections.Generic;
namespace Calculadora
{
    public class Calculadora
    {
        /*Criação da pilha resultados*/
        public Stack<long> resultados {get;set;}

        /*Criação da função construtora para instanciar a nova pilha*/
        public Calculadora()
        {
            resultados = new Stack<long>();
        }

        /*Criação da funcão para armazenar as operações na pilha*/
        public void AdicionarResultado(long resultado)
        {
            resultados.Push(resultado);
        }   
        
        public Operacoes calcular(Operacoes operacao)
        {
            switch(operacao.operador)
            {
                case '+': operacao.resultado= soma(operacao);
                AdicionarResultado(operacao.resultado); /*Função para adicionar a operação na pilha*/
                break;
                case '-': operacao.resultado = subtracao(operacao);
                AdicionarResultado(operacao.resultado); /*Função para adicionar a operação na pilha*/
                break;
                case '*': operacao.resultado = multiplicacao(operacao);
                AdicionarResultado(operacao.resultado); /*Função para adicionar a operação na pilha*/
                break;
                case '/': operacao.resultado = divisao(operacao);
                AdicionarResultado(operacao.resultado); /*Função para adicionar a operação na pilha*/
                break;
                default: operacao.resultado = 0; break;
            }
            return operacao;
        }

        private long divisao(Operacoes operacao)
        {
            return operacao.valorA / operacao.valorB;
        }

        public long soma(Operacoes operacao)
        {
            return operacao.valorA + operacao.valorB;
        }
        public long subtracao(Operacoes operacao)
        {
            return operacao.valorA - operacao.valorB;
        }
        public long multiplicacao(Operacoes operacao)
        {
            return operacao.valorA * operacao.valorB;
        }
    }
}
